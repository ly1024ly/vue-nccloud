export const ALL = 'ALL'
export const USER_INFO = 'USER_INFO'
export const FOCUS_MACHINE = 'FOCUS_MACHINE'
export const MQTT = 'MQTT'