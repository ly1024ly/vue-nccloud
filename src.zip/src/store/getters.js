export default {
	getUser(state){
    return state.user
  }
}